# weblanjut
sebelum mengakses folder ini di browser, lakukan hal-hal berikut
1. Pastikan file sql di folder database sudah diimpor di RDBMS lokal.
2. Jalankan perintah ``composer update `` di command line untuk menginstall folder vendor. Pastikan di server/komputer sudah diinstall software composer.

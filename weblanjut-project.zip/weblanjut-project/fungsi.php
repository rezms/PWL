<?php
//membuat koneksi ke database mysql
$koneksi=mysqli_connect('192.168.10.253','a122106604','polke001','a122106604');
?>

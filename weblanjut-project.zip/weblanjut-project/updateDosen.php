<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Akademik::Daftar Dosen</title>
    <link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/styleku.css">
	<script src="bootstrap4/jquery/3.3.1/jquery-3.3.1.js"></script>
	<script src="bootstrap4/js/bootstrap.js"></script>
</head>

<body>
    <div class="utama">
    <table>
        <th>NPP </th>
        <th>Nama Dosen</th>
        <th>Homebase</th>
        <br>
    
    <?php
        include "fungsi.php";
        include "head.html";
        
        $q = "SELECT * from dosen";
        $query = mysqli_query($koneksi,$q) OR die(mysqli_error($koneksi));
        
        while($rs = mysqli_fetch_object($query))
          ?>
        <tr>
            echo $rs->npp," ", $rs->namadosen, " ", $rs->homebase, "<br> ";

        
    ?>
    </table>
    </div>
</body>

</html>